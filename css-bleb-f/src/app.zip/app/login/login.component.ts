import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../authentication.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  admin = {email : '', password: ''};
  authString = null;
  constructor(private _authservice: AuthenticationService, private router: Router) { }

  ngOnInit() {
  }

  login(){
    this._authservice.authenticateLogin(this.admin).subscribe(res => {
      if(res.json().message=='Fail'){
        this.authString = "Invalid email or password.";
      }else{
        this.authString = "Loading...";
        this._authservice.login(res.json().message);
        this.router.navigate(['panel']);
      }
    });
  }
}
