import { Injectable } from '@angular/core';
import { Http, RequestOptions } from '@angular/http';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  projects = this.http.get(environment.API_HOST+"projects");
  students = this.http.get(environment.API_HOST+"students");
  categories = this.http.get(environment.API_HOST+"categories");
  beacons = this.http.get(environment.API_HOST+"beacons");
  admins = this.http.get(environment.API_HOST+"admins");

  updateStudent(student_id, student){
    var formData = new FormData();
    for ( var key in student ) {
      formData.append(key, student[key]);
    }
    return this.http.put(environment.API_HOST+"students/"+student_id, formData);
  }
  updateProject(project_id, project){
    var formData = new FormData();
    for ( var key in project ) {
      formData.append(key, project[key]);
    }
    return this.http.put(environment.API_HOST+"projects/"+project_id, formData);
  }
  updateAdmin(admin_id, admin){
    return this.http.put(environment.API_HOST+"admins/updateBasics/"+admin_id, admin);
  }

  addProject(project){
    var formData = new FormData();
    for ( var key in project ) {
      formData.append(key, project[key]);
    }
    return this.http.post(environment.API_HOST+"projects/", formData);
  }
  addStudent(student){
    var formData = new FormData();
    for ( var key in student ) {
      formData.append(key, student[key]);
    }
    
    return this.http.post(environment.API_HOST+"students/", formData);
  }

  deleteProjects(project_ids){
    return this.http.delete(environment.API_HOST+"projects/", new RequestOptions({
      body: project_ids
    }));
  }

  deleteStudents(student_ids){
    return this.http.delete(environment.API_HOST+"students/", new RequestOptions({
      body: student_ids
    }));
  }

  constructor(private http: Http) { }
}
