import { Component, OnInit, HostListener } from '@angular/core';
import { AuthenticationService } from '../../../authentication.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  constructor(private _authservice: AuthenticationService, public router: Router) { }

  ngOnInit() {
  }

  logout(){
    this._authservice.logout().subscribe(res => {
      this.router.navigate(['/']);
    });
  }


}
