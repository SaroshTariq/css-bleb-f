import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './body/dashboard/dashboard.component';
import { ProjectsComponent } from './body/projects/projects.component';
import { StudentsComponent } from './body/students/students.component';
import { NotFoundComponent } from '../not-found/not-found.component';
import { PanelComponent } from './panel.component';
import { AuthGuardService } from '../auth-guard.service';
import { AccountComponent } from './body/account/account.component';


const routes: Routes = [ 
  {path: '', component: PanelComponent, children: [
      {path: '', redirectTo: 'dashboard', pathMatch: 'full'}, 
      {path: 'dashboard', component: DashboardComponent}, 
      {path: 'students', component: StudentsComponent},
      {path: 'projects', component: ProjectsComponent},
      {path: 'account', component: AccountComponent}
    ]
  },
  
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PanelRoutingModule { }
